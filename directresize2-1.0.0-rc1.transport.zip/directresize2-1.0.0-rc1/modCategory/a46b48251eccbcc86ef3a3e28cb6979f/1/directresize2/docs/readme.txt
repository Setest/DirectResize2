--------------------
Extra: DirectResize2 (Fork of Direct Resize by Adrian Cherry)
--------------------
Version: 1.0
Created: April 8th, 2013

Author: Stepan Prishepenko {Setest} <itman116@gmail.com>
Based on: DirectResize by Adrian Cherry

License: GNU GPLv2 (or later at your option)
--------------------

A modx revo plugin to apply the a selected image expander to any images in modx Revo. The available packages are available for selection via the plugin properties.

* Highslide
* Colorbox
* prettyPhoto

IMPORTANT NOTE: Highslide JS is licensed under a Creative Commons Attribution-NonCommercial 2.5 License. This means you need the author's permission to use Highslide JS on commercial websites.

Whilst free for personal and non-profit organisations, if you are using highslide for a commercial site then you must purchase a license.

--------------------

https://github.com/Setest/DirectResize2